module.exports = {
  singleQuote: true
};