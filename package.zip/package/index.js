/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

exports.stripPrivateProperties = (excludePropsArr, inputArr) => {
  const excludePropsSet = new Set(excludePropsArr);

  return inputArr.map((obj) =>
    Object.entries(obj).reduce((acc, [key, value]) => {
      if (!excludePropsSet.has(key)) {
        acc[key] = value;
      }
      return acc;
    }, {})
  );
};
exports.excludeByProperty = (excludeProp, inputArr) => {
  return inputArr.filter((obj) => {
    return obj[excludeProp] === undefined || !obj[excludeProp];
  });
};
exports.sumDeep = (inputArr) => {
  return inputArr.map((item) => {
    return item.objects.reduce(
      (accumlator, current) => {
        return { objects: accumlator.objects + current.val };
      },
      { objects: 0 }
    );
  });
};
exports.applyStatusColor = (colorToCodeMap, statusArr) => {
  const codeToColor = Object.entries(colorToCodeMap).reduce(
    (acc, [color, codes]) => {
      codes.forEach((code) => (acc[code] = color));
      return acc;
    },
    {}
  );

  return statusArr.reduce((acc, statusObj) => {
    if (codeToColor.hasOwnProperty(statusObj.status)) {
      acc.push({
        ...statusObj,
        color: codeToColor[statusObj.status],
      });
    }
    return acc;
  }, []);
};
exports.createGreeting = (greetingGenerator, greetingWord) => {
  return (name) => {
    return greetingGenerator(greetingWord, name);
  };
};
exports.setDefaults = (defaultProps) => {
  return (targetObj) => {
    return { ...defaultProps, ...targetObj };
  };
};
exports.fetchUserByNameAndUsersCompany = (userName, services) => {
  const statusPromise = services.fetchStatus();

  return services
    .fetchUsers()
    .then((users) => {
      return users.filter((user) => {
        return user.name === userName;
      })[0];
    })
    .then((user) => {
      return Promise.all([
        user,
        services.fetchCompanyById(user.companyId),
        statusPromise,
      ]);
    })
    .then(([user, company, status]) => {
      return {
        user,
        company: company,
        status,
      };
    });
};
